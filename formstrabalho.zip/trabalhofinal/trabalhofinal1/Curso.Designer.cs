﻿namespace trabalhofinal1
{
    partial class Curso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lBReferenciaCurso = new System.Windows.Forms.Label();
            this.tBReferenciaCurso = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tBNomeCurso = new System.Windows.Forms.TextBox();
            this.tBSiglaCurso = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(55, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "Criar Curso";
            // 
            // lBReferenciaCurso
            // 
            this.lBReferenciaCurso.AutoSize = true;
            this.lBReferenciaCurso.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBReferenciaCurso.Location = new System.Drawing.Point(71, 96);
            this.lBReferenciaCurso.Name = "lBReferenciaCurso";
            this.lBReferenciaCurso.Size = new System.Drawing.Size(160, 28);
            this.lBReferenciaCurso.TabIndex = 1;
            this.lBReferenciaCurso.Text = "Referencia Curso:";
            // 
            // tBReferenciaCurso
            // 
            this.tBReferenciaCurso.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBReferenciaCurso.Location = new System.Drawing.Point(237, 90);
            this.tBReferenciaCurso.Name = "tBReferenciaCurso";
            this.tBReferenciaCurso.Size = new System.Drawing.Size(280, 34);
            this.tBReferenciaCurso.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(71, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 28);
            this.label3.TabIndex = 3;
            this.label3.Text = "Nome Curso:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(71, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 28);
            this.label4.TabIndex = 4;
            this.label4.Text = "Sigla Curso:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(71, 251);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 28);
            this.label5.TabIndex = 5;
            this.label5.Text = "Data Inicio:";
            // 
            // tBNomeCurso
            // 
            this.tBNomeCurso.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBNomeCurso.Location = new System.Drawing.Point(237, 144);
            this.tBNomeCurso.Name = "tBNomeCurso";
            this.tBNomeCurso.Size = new System.Drawing.Size(280, 34);
            this.tBNomeCurso.TabIndex = 6;
            // 
            // tBSiglaCurso
            // 
            this.tBSiglaCurso.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBSiglaCurso.Location = new System.Drawing.Point(237, 197);
            this.tBSiglaCurso.Name = "tBSiglaCurso";
            this.tBSiglaCurso.Size = new System.Drawing.Size(280, 34);
            this.tBSiglaCurso.TabIndex = 7;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(490, 332);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(233, 66);
            this.button1.TabIndex = 9;
            this.button1.Text = "Adicionar Curso";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.dateTimePicker1.Location = new System.Drawing.Point(237, 253);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(280, 34);
            this.dateTimePicker1.TabIndex = 10;
            // 
            // Curso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tBSiglaCurso);
            this.Controls.Add(this.tBNomeCurso);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tBReferenciaCurso);
            this.Controls.Add(this.lBReferenciaCurso);
            this.Controls.Add(this.label1);
            this.Name = "Curso";
            this.Text = "Curso";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label lBReferenciaCurso;
        private TextBox tBReferenciaCurso;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox tBNomeCurso;
        private TextBox tBSiglaCurso;
        private Button button1;
        private DateTimePicker dateTimePicker1;
    }
}