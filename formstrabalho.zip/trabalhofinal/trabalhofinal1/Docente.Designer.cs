﻿namespace trabalhofinal1
{
    partial class Docente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lBNumeroDocente = new System.Windows.Forms.Label();
            this.tBNumeroDocente = new System.Windows.Forms.TextBox();
            this.lBNomeDocente = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lBApelidoDocente = new System.Windows.Forms.Label();
            this.tBApelidoDocente = new System.Windows.Forms.TextBox();
            this.lBDataNascimento = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.tBEmail = new System.Windows.Forms.TextBox();
            this.lBTelefone = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lBExtensao = new System.Windows.Forms.Label();
            this.tBExtensao = new System.Windows.Forms.TextBox();
            this.lBSalario = new System.Windows.Forms.Label();
            this.tBSalario = new System.Windows.Forms.TextBox();
            this.bTAdicionarDocente = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(65, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(239, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "Adicionar Docente:";
            // 
            // lBNumeroDocente
            // 
            this.lBNumeroDocente.AutoSize = true;
            this.lBNumeroDocente.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBNumeroDocente.Location = new System.Drawing.Point(65, 112);
            this.lBNumeroDocente.Name = "lBNumeroDocente";
            this.lBNumeroDocente.Size = new System.Drawing.Size(166, 28);
            this.lBNumeroDocente.TabIndex = 1;
            this.lBNumeroDocente.Text = "Numero Docente:";
            // 
            // tBNumeroDocente
            // 
            this.tBNumeroDocente.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBNumeroDocente.Location = new System.Drawing.Point(275, 109);
            this.tBNumeroDocente.Name = "tBNumeroDocente";
            this.tBNumeroDocente.Size = new System.Drawing.Size(291, 34);
            this.tBNumeroDocente.TabIndex = 2;
            // 
            // lBNomeDocente
            // 
            this.lBNomeDocente.AutoSize = true;
            this.lBNomeDocente.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBNomeDocente.Location = new System.Drawing.Point(65, 175);
            this.lBNomeDocente.Name = "lBNomeDocente";
            this.lBNomeDocente.Size = new System.Drawing.Size(148, 28);
            this.lBNomeDocente.TabIndex = 3;
            this.lBNomeDocente.Text = "Nome Docente:";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox1.Location = new System.Drawing.Point(275, 172);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(291, 34);
            this.textBox1.TabIndex = 4;
            // 
            // lBApelidoDocente
            // 
            this.lBApelidoDocente.AutoSize = true;
            this.lBApelidoDocente.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBApelidoDocente.Location = new System.Drawing.Point(65, 231);
            this.lBApelidoDocente.Name = "lBApelidoDocente";
            this.lBApelidoDocente.Size = new System.Drawing.Size(163, 28);
            this.lBApelidoDocente.TabIndex = 5;
            this.lBApelidoDocente.Text = "Apelido Docente:";
            // 
            // tBApelidoDocente
            // 
            this.tBApelidoDocente.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBApelidoDocente.Location = new System.Drawing.Point(275, 225);
            this.tBApelidoDocente.Name = "tBApelidoDocente";
            this.tBApelidoDocente.Size = new System.Drawing.Size(291, 34);
            this.tBApelidoDocente.TabIndex = 6;
            // 
            // lBDataNascimento
            // 
            this.lBDataNascimento.AutoSize = true;
            this.lBDataNascimento.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBDataNascimento.Location = new System.Drawing.Point(65, 294);
            this.lBDataNascimento.Name = "lBDataNascimento";
            this.lBDataNascimento.Size = new System.Drawing.Size(186, 28);
            this.lBDataNascimento.TabIndex = 7;
            this.lBDataNascimento.Text = "Data Nasc. Docente:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.dateTimePicker1.Location = new System.Drawing.Point(275, 288);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(291, 34);
            this.dateTimePicker1.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(65, 347);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 28);
            this.label2.TabIndex = 9;
            this.label2.Text = "Email:";
            // 
            // tBEmail
            // 
            this.tBEmail.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBEmail.Location = new System.Drawing.Point(275, 344);
            this.tBEmail.Name = "tBEmail";
            this.tBEmail.Size = new System.Drawing.Size(291, 34);
            this.tBEmail.TabIndex = 10;
            // 
            // lBTelefone
            // 
            this.lBTelefone.AutoSize = true;
            this.lBTelefone.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBTelefone.Location = new System.Drawing.Point(65, 401);
            this.lBTelefone.Name = "lBTelefone";
            this.lBTelefone.Size = new System.Drawing.Size(88, 28);
            this.lBTelefone.TabIndex = 11;
            this.lBTelefone.Text = "Telefone:";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox2.Location = new System.Drawing.Point(275, 394);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(291, 34);
            this.textBox2.TabIndex = 12;
            // 
            // lBExtensao
            // 
            this.lBExtensao.AutoSize = true;
            this.lBExtensao.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBExtensao.Location = new System.Drawing.Point(65, 455);
            this.lBExtensao.Name = "lBExtensao";
            this.lBExtensao.Size = new System.Drawing.Size(93, 28);
            this.lBExtensao.TabIndex = 13;
            this.lBExtensao.Text = "Extensão:";
            // 
            // tBExtensao
            // 
            this.tBExtensao.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBExtensao.Location = new System.Drawing.Point(275, 448);
            this.tBExtensao.Name = "tBExtensao";
            this.tBExtensao.Size = new System.Drawing.Size(291, 34);
            this.tBExtensao.TabIndex = 14;
            // 
            // lBSalario
            // 
            this.lBSalario.AutoSize = true;
            this.lBSalario.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBSalario.Location = new System.Drawing.Point(65, 505);
            this.lBSalario.Name = "lBSalario";
            this.lBSalario.Size = new System.Drawing.Size(76, 28);
            this.lBSalario.TabIndex = 15;
            this.lBSalario.Text = "Salario:";
            // 
            // tBSalario
            // 
            this.tBSalario.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBSalario.Location = new System.Drawing.Point(275, 502);
            this.tBSalario.Name = "tBSalario";
            this.tBSalario.Size = new System.Drawing.Size(291, 34);
            this.tBSalario.TabIndex = 16;
            // 
            // bTAdicionarDocente
            // 
            this.bTAdicionarDocente.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bTAdicionarDocente.Location = new System.Drawing.Point(335, 581);
            this.bTAdicionarDocente.Name = "bTAdicionarDocente";
            this.bTAdicionarDocente.Size = new System.Drawing.Size(215, 55);
            this.bTAdicionarDocente.TabIndex = 17;
            this.bTAdicionarDocente.Text = "Adicionar Docente";
            this.bTAdicionarDocente.UseVisualStyleBackColor = true;
            // 
            // Docente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(738, 667);
            this.Controls.Add(this.bTAdicionarDocente);
            this.Controls.Add(this.tBSalario);
            this.Controls.Add(this.lBSalario);
            this.Controls.Add(this.tBExtensao);
            this.Controls.Add(this.lBExtensao);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.lBTelefone);
            this.Controls.Add(this.tBEmail);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lBDataNascimento);
            this.Controls.Add(this.tBApelidoDocente);
            this.Controls.Add(this.lBApelidoDocente);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lBNomeDocente);
            this.Controls.Add(this.tBNumeroDocente);
            this.Controls.Add(this.lBNumeroDocente);
            this.Controls.Add(this.label1);
            this.Name = "Docente";
            this.Text = "Docente";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label lBNumeroDocente;
        private TextBox tBNumeroDocente;
        private Label lBNomeDocente;
        private TextBox textBox1;
        private Label lBApelidoDocente;
        private TextBox tBApelidoDocente;
        private Label lBDataNascimento;
        private DateTimePicker dateTimePicker1;
        private Label label2;
        private TextBox tBEmail;
        private Label lBTelefone;
        private TextBox textBox2;
        private Label lBExtensao;
        private TextBox tBExtensao;
        private Label lBSalario;
        private TextBox tBSalario;
        private Button bTAdicionarDocente;
    }
}