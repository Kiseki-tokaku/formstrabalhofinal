﻿namespace trabalhofinal1
{
    partial class Inscricao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lBInscricaoAlunos = new System.Windows.Forms.Label();
            this.lBNumeroAluno = new System.Windows.Forms.Label();
            this.tBNumeroAluno = new System.Windows.Forms.TextBox();
            this.lBUnidadeCurricular = new System.Windows.Forms.Label();
            this.tBUnidadeCurricular = new System.Windows.Forms.TextBox();
            this.lBAnoLetivo = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lBEpocaAvaliacao = new System.Windows.Forms.Label();
            this.tBEpocaAvaliacao = new System.Windows.Forms.TextBox();
            this.lBEstadoEpoca = new System.Windows.Forms.Label();
            this.tBEstadoEpoca = new System.Windows.Forms.TextBox();
            this.lBPresenca = new System.Windows.Forms.Label();
            this.tBPresenca = new System.Windows.Forms.TextBox();
            this.lBNota = new System.Windows.Forms.Label();
            this.tBNota = new System.Windows.Forms.TextBox();
            this.bTInscricaoAlunos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lBInscricaoAlunos
            // 
            this.lBInscricaoAlunos.AutoSize = true;
            this.lBInscricaoAlunos.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lBInscricaoAlunos.Location = new System.Drawing.Point(74, 36);
            this.lBInscricaoAlunos.Name = "lBInscricaoAlunos";
            this.lBInscricaoAlunos.Size = new System.Drawing.Size(206, 35);
            this.lBInscricaoAlunos.TabIndex = 0;
            this.lBInscricaoAlunos.Text = "Inscrição Alunos";
            // 
            // lBNumeroAluno
            // 
            this.lBNumeroAluno.AutoSize = true;
            this.lBNumeroAluno.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBNumeroAluno.Location = new System.Drawing.Point(89, 126);
            this.lBNumeroAluno.Name = "lBNumeroAluno";
            this.lBNumeroAluno.Size = new System.Drawing.Size(145, 28);
            this.lBNumeroAluno.TabIndex = 1;
            this.lBNumeroAluno.Text = "Numero Aluno:";
            // 
            // tBNumeroAluno
            // 
            this.tBNumeroAluno.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBNumeroAluno.Location = new System.Drawing.Point(274, 123);
            this.tBNumeroAluno.Name = "tBNumeroAluno";
            this.tBNumeroAluno.Size = new System.Drawing.Size(273, 34);
            this.tBNumeroAluno.TabIndex = 2;
            // 
            // lBUnidadeCurricular
            // 
            this.lBUnidadeCurricular.AutoSize = true;
            this.lBUnidadeCurricular.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBUnidadeCurricular.Location = new System.Drawing.Point(89, 176);
            this.lBUnidadeCurricular.Name = "lBUnidadeCurricular";
            this.lBUnidadeCurricular.Size = new System.Drawing.Size(179, 28);
            this.lBUnidadeCurricular.TabIndex = 3;
            this.lBUnidadeCurricular.Text = "Unidade Curricular:";
            // 
            // tBUnidadeCurricular
            // 
            this.tBUnidadeCurricular.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBUnidadeCurricular.Location = new System.Drawing.Point(274, 173);
            this.tBUnidadeCurricular.Name = "tBUnidadeCurricular";
            this.tBUnidadeCurricular.Size = new System.Drawing.Size(273, 34);
            this.tBUnidadeCurricular.TabIndex = 4;
            // 
            // lBAnoLetivo
            // 
            this.lBAnoLetivo.AutoSize = true;
            this.lBAnoLetivo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBAnoLetivo.Location = new System.Drawing.Point(89, 222);
            this.lBAnoLetivo.Name = "lBAnoLetivo";
            this.lBAnoLetivo.Size = new System.Drawing.Size(110, 28);
            this.lBAnoLetivo.TabIndex = 5;
            this.lBAnoLetivo.Text = "Ano Letivo:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.dateTimePicker1.Location = new System.Drawing.Point(274, 222);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(273, 34);
            this.dateTimePicker1.TabIndex = 6;
            // 
            // lBEpocaAvaliacao
            // 
            this.lBEpocaAvaliacao.AutoSize = true;
            this.lBEpocaAvaliacao.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBEpocaAvaliacao.Location = new System.Drawing.Point(89, 267);
            this.lBEpocaAvaliacao.Name = "lBEpocaAvaliacao";
            this.lBEpocaAvaliacao.Size = new System.Drawing.Size(158, 28);
            this.lBEpocaAvaliacao.TabIndex = 7;
            this.lBEpocaAvaliacao.Text = "Epoca Avaliação:";
            // 
            // tBEpocaAvaliacao
            // 
            this.tBEpocaAvaliacao.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBEpocaAvaliacao.Location = new System.Drawing.Point(274, 264);
            this.tBEpocaAvaliacao.Name = "tBEpocaAvaliacao";
            this.tBEpocaAvaliacao.Size = new System.Drawing.Size(273, 34);
            this.tBEpocaAvaliacao.TabIndex = 8;
            // 
            // lBEstadoEpoca
            // 
            this.lBEstadoEpoca.AutoSize = true;
            this.lBEstadoEpoca.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBEstadoEpoca.Location = new System.Drawing.Point(89, 311);
            this.lBEstadoEpoca.Name = "lBEstadoEpoca";
            this.lBEstadoEpoca.Size = new System.Drawing.Size(133, 28);
            this.lBEstadoEpoca.TabIndex = 9;
            this.lBEstadoEpoca.Text = "Estado Epoca:";
            // 
            // tBEstadoEpoca
            // 
            this.tBEstadoEpoca.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBEstadoEpoca.Location = new System.Drawing.Point(274, 308);
            this.tBEstadoEpoca.Name = "tBEstadoEpoca";
            this.tBEstadoEpoca.Size = new System.Drawing.Size(273, 34);
            this.tBEstadoEpoca.TabIndex = 10;
            // 
            // lBPresenca
            // 
            this.lBPresenca.AutoSize = true;
            this.lBPresenca.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBPresenca.Location = new System.Drawing.Point(89, 355);
            this.lBPresenca.Name = "lBPresenca";
            this.lBPresenca.Size = new System.Drawing.Size(92, 28);
            this.lBPresenca.TabIndex = 11;
            this.lBPresenca.Text = "Presença:";
            // 
            // tBPresenca
            // 
            this.tBPresenca.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBPresenca.Location = new System.Drawing.Point(274, 352);
            this.tBPresenca.Name = "tBPresenca";
            this.tBPresenca.Size = new System.Drawing.Size(273, 34);
            this.tBPresenca.TabIndex = 12;
            // 
            // lBNota
            // 
            this.lBNota.AutoSize = true;
            this.lBNota.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBNota.Location = new System.Drawing.Point(89, 400);
            this.lBNota.Name = "lBNota";
            this.lBNota.Size = new System.Drawing.Size(60, 28);
            this.lBNota.TabIndex = 13;
            this.lBNota.Text = "Nota:";
            // 
            // tBNota
            // 
            this.tBNota.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBNota.Location = new System.Drawing.Point(274, 397);
            this.tBNota.Name = "tBNota";
            this.tBNota.Size = new System.Drawing.Size(273, 34);
            this.tBNota.TabIndex = 14;
            // 
            // bTInscricaoAlunos
            // 
            this.bTInscricaoAlunos.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bTInscricaoAlunos.Location = new System.Drawing.Point(379, 490);
            this.bTInscricaoAlunos.Name = "bTInscricaoAlunos";
            this.bTInscricaoAlunos.Size = new System.Drawing.Size(168, 49);
            this.bTInscricaoAlunos.TabIndex = 15;
            this.bTInscricaoAlunos.Text = "Submeter Inscrição";
            this.bTInscricaoAlunos.UseVisualStyleBackColor = true;
            // 
            // Inscricao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(659, 596);
            this.Controls.Add(this.bTInscricaoAlunos);
            this.Controls.Add(this.tBNota);
            this.Controls.Add(this.lBNota);
            this.Controls.Add(this.tBPresenca);
            this.Controls.Add(this.lBPresenca);
            this.Controls.Add(this.tBEstadoEpoca);
            this.Controls.Add(this.lBEstadoEpoca);
            this.Controls.Add(this.tBEpocaAvaliacao);
            this.Controls.Add(this.lBEpocaAvaliacao);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lBAnoLetivo);
            this.Controls.Add(this.tBUnidadeCurricular);
            this.Controls.Add(this.lBUnidadeCurricular);
            this.Controls.Add(this.tBNumeroAluno);
            this.Controls.Add(this.lBNumeroAluno);
            this.Controls.Add(this.lBInscricaoAlunos);
            this.Name = "Inscricao";
            this.Text = "Inscricao";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lBInscricaoAlunos;
        private Label lBNumeroAluno;
        private TextBox tBNumeroAluno;
        private Label lBUnidadeCurricular;
        private TextBox tBUnidadeCurricular;
        private Label lBAnoLetivo;
        private DateTimePicker dateTimePicker1;
        private Label lBEpocaAvaliacao;
        private TextBox tBEpocaAvaliacao;
        private Label lBEstadoEpoca;
        private TextBox tBEstadoEpoca;
        private Label lBPresenca;
        private TextBox tBPresenca;
        private Label lBNota;
        private TextBox tBNota;
        private Button bTInscricaoAlunos;
    }
}