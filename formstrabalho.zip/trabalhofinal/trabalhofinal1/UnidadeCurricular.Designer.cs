﻿namespace trabalhofinal1
{
    partial class UnidadeCurricular
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lBAdicionarUnidadeCurricular = new System.Windows.Forms.Label();
            this.lBReferenciaUC = new System.Windows.Forms.Label();
            this.tBRefeenciaUC = new System.Windows.Forms.TextBox();
            this.lBRefCursoUC = new System.Windows.Forms.Label();
            this.tBRefCursoUC = new System.Windows.Forms.TextBox();
            this.lBNumeroDocenteUC = new System.Windows.Forms.Label();
            this.tBNumeroDocenteUC = new System.Windows.Forms.TextBox();
            this.lBNomeUC = new System.Windows.Forms.Label();
            this.tBNomeUC = new System.Windows.Forms.TextBox();
            this.lBSiglaUC = new System.Windows.Forms.Label();
            this.tBSiglaUC = new System.Windows.Forms.TextBox();
            this.lBCreditosUC = new System.Windows.Forms.Label();
            this.tBCreditosUC = new System.Windows.Forms.TextBox();
            this.lBAnoUC = new System.Windows.Forms.Label();
            this.tBAnoUC = new System.Windows.Forms.TextBox();
            this.lBSemestreUC = new System.Windows.Forms.Label();
            this.tBSemestreUC = new System.Windows.Forms.TextBox();
            this.bTAddicionarUC = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lBAdicionarUnidadeCurricular
            // 
            this.lBAdicionarUnidadeCurricular.AutoSize = true;
            this.lBAdicionarUnidadeCurricular.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lBAdicionarUnidadeCurricular.Location = new System.Drawing.Point(65, 32);
            this.lBAdicionarUnidadeCurricular.Name = "lBAdicionarUnidadeCurricular";
            this.lBAdicionarUnidadeCurricular.Size = new System.Drawing.Size(353, 35);
            this.lBAdicionarUnidadeCurricular.TabIndex = 0;
            this.lBAdicionarUnidadeCurricular.Text = "Adicionar Unidade Curricular";
            // 
            // lBReferenciaUC
            // 
            this.lBReferenciaUC.AutoSize = true;
            this.lBReferenciaUC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBReferenciaUC.Location = new System.Drawing.Point(87, 111);
            this.lBReferenciaUC.Name = "lBReferenciaUC";
            this.lBReferenciaUC.Size = new System.Drawing.Size(136, 28);
            this.lBReferenciaUC.TabIndex = 1;
            this.lBReferenciaUC.Text = "Referencia UC:";
            // 
            // tBRefeenciaUC
            // 
            this.tBRefeenciaUC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBRefeenciaUC.Location = new System.Drawing.Point(229, 111);
            this.tBRefeenciaUC.Name = "tBRefeenciaUC";
            this.tBRefeenciaUC.Size = new System.Drawing.Size(293, 34);
            this.tBRefeenciaUC.TabIndex = 2;
            // 
            // lBRefCursoUC
            // 
            this.lBRefCursoUC.AutoSize = true;
            this.lBRefCursoUC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBRefCursoUC.Location = new System.Drawing.Point(87, 157);
            this.lBRefCursoUC.Name = "lBRefCursoUC";
            this.lBRefCursoUC.Size = new System.Drawing.Size(160, 28);
            this.lBRefCursoUC.TabIndex = 3;
            this.lBRefCursoUC.Text = "Referencia Curso:";
            // 
            // tBRefCursoUC
            // 
            this.tBRefCursoUC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBRefCursoUC.Location = new System.Drawing.Point(253, 154);
            this.tBRefCursoUC.Name = "tBRefCursoUC";
            this.tBRefCursoUC.Size = new System.Drawing.Size(269, 34);
            this.tBRefCursoUC.TabIndex = 4;
            // 
            // lBNumeroDocenteUC
            // 
            this.lBNumeroDocenteUC.AutoSize = true;
            this.lBNumeroDocenteUC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBNumeroDocenteUC.Location = new System.Drawing.Point(87, 200);
            this.lBNumeroDocenteUC.Name = "lBNumeroDocenteUC";
            this.lBNumeroDocenteUC.Size = new System.Drawing.Size(224, 28);
            this.lBNumeroDocenteUC.TabIndex = 5;
            this.lBNumeroDocenteUC.Text = "Numero Docente da UC:";
            // 
            // tBNumeroDocenteUC
            // 
            this.tBNumeroDocenteUC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBNumeroDocenteUC.Location = new System.Drawing.Point(317, 197);
            this.tBNumeroDocenteUC.Name = "tBNumeroDocenteUC";
            this.tBNumeroDocenteUC.Size = new System.Drawing.Size(205, 34);
            this.tBNumeroDocenteUC.TabIndex = 6;
            // 
            // lBNomeUC
            // 
            this.lBNomeUC.AutoSize = true;
            this.lBNomeUC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBNomeUC.Location = new System.Drawing.Point(87, 245);
            this.lBNomeUC.Name = "lBNomeUC";
            this.lBNomeUC.Size = new System.Drawing.Size(101, 28);
            this.lBNomeUC.TabIndex = 7;
            this.lBNomeUC.Text = "Nome UC:";
            // 
            // tBNomeUC
            // 
            this.tBNomeUC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBNomeUC.Location = new System.Drawing.Point(194, 242);
            this.tBNomeUC.Name = "tBNomeUC";
            this.tBNomeUC.Size = new System.Drawing.Size(328, 34);
            this.tBNomeUC.TabIndex = 8;
            // 
            // lBSiglaUC
            // 
            this.lBSiglaUC.AutoSize = true;
            this.lBSiglaUC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBSiglaUC.Location = new System.Drawing.Point(87, 284);
            this.lBSiglaUC.Name = "lBSiglaUC";
            this.lBSiglaUC.Size = new System.Drawing.Size(90, 28);
            this.lBSiglaUC.TabIndex = 9;
            this.lBSiglaUC.Text = "Sigla UC:";
            // 
            // tBSiglaUC
            // 
            this.tBSiglaUC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBSiglaUC.Location = new System.Drawing.Point(183, 281);
            this.tBSiglaUC.Name = "tBSiglaUC";
            this.tBSiglaUC.Size = new System.Drawing.Size(339, 34);
            this.tBSiglaUC.TabIndex = 10;
            // 
            // lBCreditosUC
            // 
            this.lBCreditosUC.AutoSize = true;
            this.lBCreditosUC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBCreditosUC.Location = new System.Drawing.Point(87, 331);
            this.lBCreditosUC.Name = "lBCreditosUC";
            this.lBCreditosUC.Size = new System.Drawing.Size(147, 28);
            this.lBCreditosUC.TabIndex = 11;
            this.lBCreditosUC.Text = "Creditos da UC:";
            // 
            // tBCreditosUC
            // 
            this.tBCreditosUC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBCreditosUC.Location = new System.Drawing.Point(240, 328);
            this.tBCreditosUC.Name = "tBCreditosUC";
            this.tBCreditosUC.Size = new System.Drawing.Size(282, 34);
            this.tBCreditosUC.TabIndex = 12;
            // 
            // lBAnoUC
            // 
            this.lBAnoUC.AutoSize = true;
            this.lBAnoUC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBAnoUC.Location = new System.Drawing.Point(87, 374);
            this.lBAnoUC.Name = "lBAnoUC";
            this.lBAnoUC.Size = new System.Drawing.Size(110, 28);
            this.lBAnoUC.TabIndex = 13;
            this.lBAnoUC.Text = "Ano da UC:";
            // 
            // tBAnoUC
            // 
            this.tBAnoUC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBAnoUC.Location = new System.Drawing.Point(203, 371);
            this.tBAnoUC.Name = "tBAnoUC";
            this.tBAnoUC.Size = new System.Drawing.Size(319, 34);
            this.tBAnoUC.TabIndex = 14;
            // 
            // lBSemestreUC
            // 
            this.lBSemestreUC.AutoSize = true;
            this.lBSemestreUC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lBSemestreUC.Location = new System.Drawing.Point(87, 418);
            this.lBSemestreUC.Name = "lBSemestreUC";
            this.lBSemestreUC.Size = new System.Drawing.Size(154, 28);
            this.lBSemestreUC.TabIndex = 15;
            this.lBSemestreUC.Text = "Semestre da UC:";
            // 
            // tBSemestreUC
            // 
            this.tBSemestreUC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tBSemestreUC.Location = new System.Drawing.Point(247, 415);
            this.tBSemestreUC.Name = "tBSemestreUC";
            this.tBSemestreUC.Size = new System.Drawing.Size(275, 34);
            this.tBSemestreUC.TabIndex = 16;
            // 
            // bTAddicionarUC
            // 
            this.bTAddicionarUC.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bTAddicionarUC.Location = new System.Drawing.Point(331, 484);
            this.bTAddicionarUC.Name = "bTAddicionarUC";
            this.bTAddicionarUC.Size = new System.Drawing.Size(191, 65);
            this.bTAddicionarUC.TabIndex = 17;
            this.bTAddicionarUC.Text = "Adicionar UC";
            this.bTAddicionarUC.UseVisualStyleBackColor = true;
            // 
            // UnidadeCurricular
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 598);
            this.Controls.Add(this.bTAddicionarUC);
            this.Controls.Add(this.tBSemestreUC);
            this.Controls.Add(this.lBSemestreUC);
            this.Controls.Add(this.tBAnoUC);
            this.Controls.Add(this.lBAnoUC);
            this.Controls.Add(this.tBCreditosUC);
            this.Controls.Add(this.lBCreditosUC);
            this.Controls.Add(this.tBSiglaUC);
            this.Controls.Add(this.lBSiglaUC);
            this.Controls.Add(this.tBNomeUC);
            this.Controls.Add(this.lBNomeUC);
            this.Controls.Add(this.tBNumeroDocenteUC);
            this.Controls.Add(this.lBNumeroDocenteUC);
            this.Controls.Add(this.tBRefCursoUC);
            this.Controls.Add(this.lBRefCursoUC);
            this.Controls.Add(this.tBRefeenciaUC);
            this.Controls.Add(this.lBReferenciaUC);
            this.Controls.Add(this.lBAdicionarUnidadeCurricular);
            this.Name = "UnidadeCurricular";
            this.Text = "UnidadeCurricular";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lBAdicionarUnidadeCurricular;
        private Label lBReferenciaUC;
        private TextBox tBRefeenciaUC;
        private Label lBRefCursoUC;
        private TextBox tBRefCursoUC;
        private Label lBNumeroDocenteUC;
        private TextBox tBNumeroDocenteUC;
        private Label lBNomeUC;
        private TextBox tBNomeUC;
        private Label lBSiglaUC;
        private TextBox tBSiglaUC;
        private Label lBCreditosUC;
        private TextBox tBCreditosUC;
        private Label lBAnoUC;
        private TextBox tBAnoUC;
        private Label lBSemestreUC;
        private TextBox tBSemestreUC;
        private Button bTAddicionarUC;
    }
}